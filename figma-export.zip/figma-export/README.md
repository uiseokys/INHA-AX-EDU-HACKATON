# 쓰담 · Figma 작업용 화면 자료

쓰담 Python 웹 프로토타입(`ssudam-py`)의 현재 화면을 Figma에서 작업할 수 있도록 내보낸 자료입니다.
화면 속 학생·기관 정보는 모두 시연용 합성 데이터입니다.

| 폴더 | 내용 | Figma에서 쓰는 법 |
| --- | --- | --- |
| `screens/` | 화면별 PNG. 데스크톱 1440px, 모바일 390px | Figma 캔버스에 끌어다 놓기. 참고 이미지나 트레이싱용 |
| `html/` | 화면별 단독 HTML (CSS 포함) | 편집 가능한 레이어로 바꾸고 싶을 때 사용 (아래 참고) |
| `tokens/tokens.json` | 색·글자·모서리·그림자·레이아웃 값 (W3C Design Tokens 형식) | Tokens Studio 같은 토큰 플러그인으로 불러오기 |
| `tokens/token-sheet.png` | 위 토큰을 한 장에 정리한 이미지 | 스타일 기준표로 캔버스에 배치 |
| `manifest.json` | 화면 이름·주소·파일 목록 | 참고용 |

- 모바일 화면 중 세로가 4096px을 넘는 것은 `-part1`, `-part2`로 나눠 저장했습니다. Figma가 한 변이 4096px을 넘는 이미지를 자동으로 축소하기 때문입니다.
- 글꼴은 **Pretendard**입니다. Figma에서 같은 모양으로 작업하려면 Pretendard를 설치해 주세요.

## 화면 목록

| 파일 | 화면 | 코드에서 고칠 파일 (`ssudam-py/app/templates/`) |
| --- | --- | --- |
| `01-landing` | 랜딩 | `landing.html` |
| `02-student-home` | 학생 홈 · 체크인 전 | `student_home.html` |
| `03-student-support` | 도움 요청 · 요청 전 | `student_support.html` |
| `04-student-checkin-input` | 학생 홈 · 감정 선택 후 입력 단계 | `student_home.html` |
| `05-student-home-checked` | 학생 홈 · 체크인 완료 | `student_home.html` |
| `06-student-insights` | 마음 분석 | `student_insights.html` |
| `07-student-support-sent` | 도움 요청 · 요청 보낸 뒤 | `student_support.html` |
| `08-teacher-dashboard` | 상담교사 · 요청 현황 | `teacher_home.html` |
| `09-teacher-student` | 상담교사 · 학생 상세 (그래프 공유) | `teacher_student.html` |
| `10-teacher-student-private` | 상담교사 · 학생 상세 (그래프 비공유) | `teacher_student.html` |
| `11-agencies` | 지원기관 추천 | `agencies.html` |
| `12-agency-modal` | 지원기관 · 연결 요청 창 | `agencies.html` |

상단 메뉴·하단 탭은 `layout.html`, 그래프·로고·카드 제목 같은 공통 요소는 `_ui.html`에 있습니다.

## 편집 가능한 레이어로 바꾸려면

PNG는 이미지라서 글자나 색을 바로 고칠 수 없습니다. 레이어로 쓰고 싶다면 HTML을 Figma 레이어로 바꿔 주는 외부 플러그인(예: html.to.design)을 사용할 수 있습니다.

1. `html/` 안의 파일을 Chrome에서 엽니다.
2. 플러그인의 Chrome 확장 프로그램으로 지금 보는 화면을 가져옵니다. (로컬 파일을 확장 프로그램이 읽으려면 Chrome 확장 설정에서 "파일 URL에 대한 액세스 허용"을 켜야 할 수 있습니다)
3. Figma에서 플러그인을 열어 가져온 화면을 불러옵니다.

플러그인의 사용 방법과 요금은 해당 서비스의 안내를 따르세요. 변환 결과는 원본과 조금 다를 수 있습니다.

## 디자인을 코드에 반영하는 방법

Figma에서 수정한 화면의 **프레임 링크**(프레임 우클릭 → Copy link)를 Claude에게 전달하면, 그 디자인을 보고 `ssudam-py` 코드에 반영할 수 있습니다. 이를 위해 Claude 쪽에 Figma 연결이 되어 있어야 합니다.

## 다시 내보내기

화면을 고친 뒤 자료를 새로 만들려면 `ssudam-py/scripts/export_for_figma.py` 맨 위 설명을 따라 실행하세요. (Google Chrome, Pillow 필요)
